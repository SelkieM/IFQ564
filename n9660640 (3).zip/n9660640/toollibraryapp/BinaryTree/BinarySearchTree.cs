﻿class BinarySearchTree<T> where T : IComparable<T>
{
    private TreeNode<T> root;

    // Constructor for creating a new binary search tree.
    public BinarySearchTree()
    {
        root = null; // Initialize the root as null, indicating an empty tree.
    }

    // Insert a new data element into the binary search tree.
    public void Insert(T data)
    {
        root = Insert(root, data); // Call the private Insert method.
    }

    // Private method for recursive insertion.
    private TreeNode<T> Insert(TreeNode<T> node, T data)
    {
        if (node == null)
        {
            return new TreeNode<T>(data); // Create a new node when reaching an empty spot.
        }

        int compareResult = data.CompareTo(node.Data);

        if (compareResult < 0)
        {
            node.Left = Insert(node.Left, data); // Insert into the left subtree.
        }
        else if (compareResult > 0)
        {
            node.Right = Insert(node.Right, data); // Insert into the right subtree.
        }

        return node;
    }

    // Check if the binary search tree is empty.
    public bool IsEmpty()
    {
        return root == null; // Tree is empty if the root is null.
    }

    // Check if the tree contains a specific data element.
    public T? Contains(T data)
    {
        return Contains(root, data); // Call the private Contains method.
    }

    // Private method for recursive search.
    private T? Contains(TreeNode<T> node, T data)
    {
        if (node == null)
        {
            return default(T); // Data not found; return the default value for type T.
        }

        int compareResult = data.CompareTo(node.Data);

        if (compareResult == 0)
        {
            return node.Data; // Data found.
        }
        else if (compareResult < 0)
        {
            return Contains(node.Left, data); // Search in the left subtree.
        }
        else
        {
            return Contains(node.Right, data); // Search in the right subtree.
        }
    }

    // Remove a specific data element from the binary search tree.
    public void Remove(T data)
    {
        root = Remove(root, data); // Call the private Remove method.
    }

    // Private method for recursive removal.
    private TreeNode<T> Remove(TreeNode<T> node, T data)
    {
        if (node == null)
        {
            return null; // Data not found; nothing to remove.
        }

        int compareResult = data.CompareTo(node.Data);

        if (compareResult < 0)
        {
            node.Left = Remove(node.Left, data); // Remove from the left subtree.
        }
        else if (compareResult > 0)
        {
            node.Right = Remove(node.Right, data); // Remove from the right subtree.
        }
        else
        {
            // Node with the data to be removed found

            // Case 1: Node with only one child or no child
            if (node.Left == null)
            {
                return node.Right; // Replace with the right child (or null).
            }
            else if (node.Right == null)
            {
                return node.Left; // Replace with the left child.
            }

            // Case 2: Node with two children
            node.Data = FindMinValue(node.Right); // Replace with the in-order successor.
            node.Right = Remove(node.Right, node.Data); // Remove the in-order successor.
        }

        return node;
    }

    // Find the minimum value in the tree rooted at a given node.
    private T FindMinValue(TreeNode<T> node)
    {
        T minValue = node.Data;
        while (node.Left != null)
        {
            minValue = node.Left.Data;
            node = node.Left;
        }
        return minValue;
    }

    // Perform an in-order traversal of the tree and execute an action on each node's data.
    public void InOrderTraversal(Action<T> action)
    {
        InOrderTraversal(root, action); // Call the private InOrderTraversal method.
    }

    // Private method for recursive in-order traversal.
    private void InOrderTraversal(TreeNode<T> node, Action<T> action)
    {
        if (node == null)
        {
            return;
        }

        InOrderTraversal(node.Left, action); // Traverse left subtree.
        action(node.Data); // Execute action on the current node's data.
        InOrderTraversal(node.Right, action); // Traverse right subtree.
    }
}