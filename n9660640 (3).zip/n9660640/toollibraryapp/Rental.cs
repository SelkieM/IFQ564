﻿class Rental : IComparable<Rental>
{
    public string ToolName { get; set; }
    public string PersonFullName { get; set; }
    public string PersonContactPhoneNumber { get; set; }
    public int Quantity { get; set; }

    public Rental(string ToolName, string PersonFullName, string PersonContactPhoneNumber, int quantity)
    {
        ToolName = ToolName;
        PersonFullName = PersonFullName;
        PersonContactPhoneNumber = PersonContactPhoneNumber;
        Quantity = quantity;
    }

    public int CompareTo(Rental other)
    {
        if (other == null)
        {
            // By convention, when comparing to null, the object is considered greater.
            return 1;
        }

        // Compare Rental objects based on their ToolName property.
        return string.Compare(ToolName + PersonContactPhoneNumber, other.ToolName + other.PersonContactPhoneNumber, StringComparison.Ordinal);
    }
}