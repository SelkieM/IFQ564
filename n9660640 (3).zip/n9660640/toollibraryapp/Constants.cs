﻿public enum ToolType
{
    Gardening,
    Flooring,
    Fencing,
    Measuring,
    Cleaning,
    Painting,
    Electronic,
    Electricity,
    Automotive
}