﻿class Tool : IComparable<Tool>
{
    public string Name { get; set; }
    public ToolType Type { get; set; }
    public string Description { get; set; }
    public int Quantity { get; set; }

    public Tool(string name, ToolType type, string description, int quantity)
    {
        Name = name;
        Description = description;
        Quantity = quantity;
        Type = type;
    }

    public int CompareTo(Tool? other)
    {
        if (other == null)
        {
            return 1;
        }
        return string.Compare(Name, other.Name, StringComparison.Ordinal);
    }

    // Convert ToolType to string for display
    public string GetToolTypeAsString()
    {
        return Type.ToString();
    }
}