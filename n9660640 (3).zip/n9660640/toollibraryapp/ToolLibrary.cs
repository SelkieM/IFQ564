﻿public class ToolLibrary
{
    // Private fields to store tools and rentals using BinarySearchTree.
    private BinarySearchTree<Tool> tools;
    private BinarySearchTree<Rental> rentals;

    // Constructor to initialize the tool and rental collections.
    public ToolLibrary()
    {
        tools = new BinarySearchTree<Tool>();
        rentals = new BinarySearchTree<Rental>();
    }

    // Method to display tools of a specific type.
    public void DisplayTools(string type)
    {
        // Capitalize the first letter and convert the rest to lowercase for consistency.
        type = $"{type.First().ToString().ToUpper()}{type.Substring(1).ToLower()}";

        // Check if the input type is a valid ToolType.
        if (Enum.IsDefined(typeof(ToolType), type))
        {
            // Check if the tools collection is empty.
            if (tools.IsEmpty())
            {
                Console.WriteLine("There are no tools available in this type.");
            }

            // Traverse the tools collection and display tools of the specified type.
            tools.InOrderTraversal(data =>
            {
                if (data.GetToolTypeAsString() == type)
                {
                    Console.WriteLine($"Name: {data.Name}");
                    Console.WriteLine($"Description: {data.Description}");
                    Console.WriteLine($"Availability: {data.Quantity} available\n");
                }
            });
        }
        else
        {
            Console.WriteLine("This type of tool is not available.");
        }
    }

    // Method to add a new tool to the library.
    public void AddTool(string name, string type, string description, int quantity)
    {
        // Capitalize the first letter and convert the rest to lowercase for consistency.
        type = $"{type.First().ToString().ToUpper()}{type.Substring(1).ToLower()}";

        // Check if the input type is a valid ToolType.
        if (Enum.IsDefined(typeof(ToolType), type))
        {
            // Convert the type string to a ToolType enum.
            ToolType toolType = (ToolType)Enum.Parse(typeof(ToolType), type);

            // Create a new tool with the provided information.
            Tool tool = new Tool(name, toolType, description, quantity);

            // Check if a tool with the same name and type already exists.
            Tool existingTool = tools.Contains(tool);

            if (existingTool != null)
            {
                // Update the quantity of the existing tool.
                existingTool.Quantity += quantity;
            }
            else
            {
                // Insert the new tool into the tools collection.
                tools.Insert(tool);
            }

            Console.WriteLine("Tool added successfully.");
        }
        else
        {
            Console.WriteLine("This type of tool is not available.");
        }
    }

    // Method to lend tools to a person.
    public void LendTool(string type, string name, string personFullName, string contactPhoneNumber, int quantity)
    {
        // Capitalize the first letter and convert the rest to lowercase for consistency.
        type = $"{type.First().ToString().ToUpper()}{type.Substring(1).ToLower()}";

        // Check if the input type is a valid ToolType.
        if (Enum.IsDefined(typeof(ToolType), type))
        {
            // Convert the type string to a ToolType enum.
            ToolType toolType = (ToolType)Enum.Parse(typeof(ToolType), type);

            // Find the tool to lend based on name, type, and quantity.
            var toolToLend = tools.Contains(new Tool(name, toolType, "", quantity));

            if (toolToLend != null && toolToLend.Quantity >= quantity)
            {
                // Decrease the quantity of the tool being lent.
                toolToLend.Quantity -= quantity;

                // Create a rental record for the lent tool.
                Rental rental = new Rental(name, personFullName, contactPhoneNumber, quantity);

                // Check if a rental record for the same tool already exists.
                Rental existingRental = rentals.Contains(rental);

                if (existingRental != null)
                {
                    // Update the quantity in the existing rental record.
                    existingRental.Quantity += quantity;
                }
                else
                {
                    // Insert the new rental record into the rentals collection.
                    rentals.Insert(rental);
                }

                Console.WriteLine("Tool(s) lent successfully.");
            }
            else
            {
                Console.WriteLine("Insufficient quantity of this tool available.");
            }
        }
        else
        {
            Console.WriteLine("This type of tool is not available.");
        }
    }

    // Method to return lent tools.
    public void ReturnTool(string name, string contactPhoneNumber, int quantity)
    {
        // Create a rental object to identify the tool being returned.
        var rental = new Rental(name, "", contactPhoneNumber, quantity);

        // Find the rental record in the rentals collection.
        var existingRental = rentals.Contains(rental);

        if (existingRental != null)
        {
            if (existingRental.Quantity >= quantity)
            {
                // Decrease the quantity in the rental record.
                existingRental.Quantity -= quantity;

                // Find the corresponding tool in the tools collection.
                var tool = tools.Contains(new Tool(name, ToolType.Cleaning, "", quantity));

                if (tool != null)
                {
                    // Increase the quantity of the returned tool.
                    tool.Quantity += quantity;
                }

                // Remove the rental record if the quantity reaches zero.
                if (rental.Quantity == 0)
                {
                    rentals.Remove(existingRental);
                }

                Console.WriteLine("Tool(s) returned successfully.");
            }
            else
            {
                Console.WriteLine("Incorrect quantity of tools returned.");
            }
        }
        else
        {
            Console.WriteLine("Rental record not found.");
        }
    }
}