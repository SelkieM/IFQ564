﻿public class Program
{
    public static void Main(string[] args)
    {
        // Create an instance of the ToolLibrary class to manage tools.
        ToolLibrary toolLibrary = new ToolLibrary();

        while (true)
        {
            // Display the main menu for the Inventory Management System.
            Console.WriteLine("\nInventory Management System Menu:");
            Console.WriteLine("1. Display Tools");
            Console.WriteLine("2. Add New Tool");
            Console.WriteLine("3. Lend Tool");
            Console.WriteLine("4. Return Tool");
            Console.WriteLine("5. Exit");

            // Read the user's choice from the console.
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    // Option 1: Display Tools
                    Console.Write("Enter the tool type to display: ");
                    string toolType = Console.ReadLine();
                    toolLibrary.DisplayTools(toolType);
                    break;

                case "2":
                    // Option 2: Add New Tool
                    Console.Write("Enter the tool type: ");
                    string toolTypeToAdd = Console.ReadLine();
                    Console.Write("Enter the name of the tool: ");
                    string nameToAdd = Console.ReadLine();
                    Console.Write("Enter a brief description: ");
                    string descriptionToAdd = Console.ReadLine();
                    Console.Write("Enter the quantity: ");
                    int quantityToAdd = int.Parse(Console.ReadLine());
                    toolLibrary.AddTool(nameToAdd, toolTypeToAdd, descriptionToAdd, quantityToAdd);
                    break;

                case "3":
                    // Option 3: Lend Tool
                    Console.Write("Enter the tool type: ");
                    string toolTypeToLend = Console.ReadLine();
                    Console.Write("Enter the name of the tool: ");
                    string nameToLend = Console.ReadLine();
                    Console.Write("Enter your name: ");
                    string personName = Console.ReadLine();
                    Console.Write("Enter your contact phone: ");
                    string contactPhone = Console.ReadLine();
                    Console.Write("Enter the quantity to lend: ");
                    int quantityToLend = int.Parse(Console.ReadLine());
                    toolLibrary.LendTool(toolTypeToLend, nameToLend, personName, contactPhone, quantityToLend);
                    break;

                case "4":
                    // Option 4: Return Tool
                    Console.Write("Enter the name of the tool: ");
                    string toolNameToReturn = Console.ReadLine();
                    Console.Write("Enter your contact phone: ");
                    string contactPhoneToReturn = Console.ReadLine();
                    Console.Write("Enter the quantity to Return: ");
                    int quantityToReturn = int.Parse(Console.ReadLine());
                    toolLibrary.ReturnTool(toolNameToReturn, contactPhoneToReturn, quantityToReturn);
                    break;

                case "5":
                    // Option 5: Exit the program
                    Console.WriteLine("Exiting...");
                    return;

                default:
                    // Handle invalid choices
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}